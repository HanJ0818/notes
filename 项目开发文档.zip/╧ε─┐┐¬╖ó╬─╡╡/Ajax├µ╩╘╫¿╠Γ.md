# Ajax

## 概念

Ajax： 异步的JavaScript和XML

（注意： ajax是遵循http协议的）

## 优点

- 在不刷新整个网页的情况下，和服务器进行数据交互，局部更新
- 用户体验好

## 缺点

- 不利于`SEO`

## 原生ajax

原生ajax，主要是通过 `XMLHttpRequest` 发送请求，接收数据。  因为不是浏览器发送请求，接收数据，而是`XMLHttpRequest`这个对象，所以， 浏览器不会刷新。



## 作用

- 发送数据给后端（表单、输入框、多选框、文本域... 字节码 二进制...(上传文件的时候)）
- 获取后端的数据，用来动态渲染



## 原生Ajax

### get方式【4步】

```js
const xhr = new XMLHttpRequest()
xhr.open('get', url?参数名=参数值)
xhr.send()
xhr.onreadystatechange = function () {
  if (xhr.readyState === 4 && xhr.status === 200) {
      let data = xhr.responseText; // 字符串
  }
}
```

### post方式【5步骤】

```js
const xhr = new XMLHttpRequest()
xhr.open('post', url)
// 发送之前 设置请求头 （axios也可以设置请求头 ）
/*
 Content-Type: 前端发送给后端的数据的类型
   application/json  // 发送给后端的数据格式时json对象
   application/x-www-form-urlencoded  // 发送给后端的数据格式是 Form 表单数据格式
   multipart/form-data  // 文件上传
*/
xhr.setRequestHeader('Content-Type', '值')
xhr.send() // 不同的Content-Type 发送的数据格式还不同
xhr.onreadystatechange = function () {
  if (xhr.readyState === 4 && xhr.status === 200) {
      let data = xhr.responseText; // 字符串
  }
}
```

http://datav.jiaminghi.com/     （datav -》 基于vue和echarts封装的组件库）



## 下载

- 使用a标签发送请求（ http请求 ）
- 使用 window.location.href 发送请求
- 使用js，动态创建a标签，发送请求

## 上传

- 创建一个FormData实例对象

  ```js
  const fd = new FromData()
  ```

- 把文件数据放入这个对象

  ```js
  fd.append('字段名', 要上传的文件) // 图片 word文档 excel 视频 音频
  ```

- 通过ajax，把这个对象发送给后端

  - 原生

    ```js
    xhr.send(fd)
    ```

  - axios

    ```js
    axios.post(url, fd).then(res => {
        console.log(res.data)
    })
    ```

## http状态码

1xx：  客户端问题，（前端）问题， 基本遇不到

2xx：  客户端问题，

- 200 成功

3xx: 

- 301:  永久重定向。 // 这个网址不用了，请访问新的网址
- 302   临时重定向。 // 这个网址暂时不用，请访问新的网址，之后会换回来
- 304： 未修改 ； 缓存； // 这一次请求的资源 和上次一样，浏览器缓存了，直接从缓存拿，不需要服务器返回

4xx：

- 400    客户端请求的语法错误  // 请求的参数格式错误，服务器接收不了
- 401  未授权 （ token错误了 或 失效了 或 过期了， 后端都会返回401未授权 ）
- 403   服务器拒绝你的请求
- 404   找不到  // 请求的地址错误
- 405  服务器不支持这个请求方式

5xx：

- 所有5开头的，都是服务器错误，和前端没有关系。



## http相关知识

### 1 概念: 

 超文本传输协议（Hyper Text Transfer Protocol，*HTTP* ,是一个简单的请求，响应协议。

http的底层，是TCP/IP协议 （ 这些都属于网络协议 ）

规定了：

- 一次请求，一次响应，谁发送的请求，就响应给谁。
- 规定了请求和响应过程中的数据`MIME类类型`(数据格式)



### 2 http1.0 1.1 2.0 区别

http 1.1

-  **缓存处理** , http1.1多了很多选择： 新增了一些缓存策略。
-  **带宽优化及网络连接的使用** ： 避免带宽浪费
-  **错误通知的管** ：  新增了一个错误码
- **Host头处理：** 设置host头域
- 支持长连接

http 2.0 

- **头部压缩**
- **多路复用**
- 二进制分帧
- 请求优先级
- 服务器推送



### 3 http请求方式

http1.0

- get     (***)
- post    (***)
- head

http1.1

- options
- put      (***)
- delete    (***)
- trace
- connect

restful风格api

- GET（SELECT）：从服务器取出资源（一项或多项）。 // 获取信息

- POST（CREATE）：在服务器新建一个资源。   // 新建

- PUT（UPDATE）：在服务器更新资源（客户端提供改变后的完整资源）。// 更新（所有）

- PATCH（UPDATE）：在服务器更新资源（客户端提供改变的属性）。 // 更新 （布局）

- DELETE（DELETE）：从服务器删除资源。// 删除



## 输入url到看到整个页面的（页面渲染）完整事务流程

- 【1】输入url（https://jd.com）, 通过dns解析域名的实际ip地址 
- 【2】检查浏览器是否有缓存， 有缓存，就直接从缓存读取，否则，请求服务器的结果
- 【3】浏览器与服务器建立TCP连接。
  - 三次握手
    - 前端：  哥，能接受我的消息吗？
    - 后端：小老弟，可以的，你能收到我的消息吗？
    - 前端：可以， 我们开始传输数据吧。
- 【4】浏览器发送请求，获取到页面 （ xxx.html的页面 ）
- 【5】服务器响应html页面，给前端
- 【6】浏览器解析html页面
  - html标签
  - style标签
  - script标签
- 【7】浏览器渲染页面
  - html解析成dom tree DOM树
  -  css解析成 rule tree   规则树
  - 两颗树合成 render tree
  - 进行layout， 布局计算， 算出网页的节点，css、每个节点在屏幕的位置
  - 绘制，遍历 render tree，把页面画出来
- 【8】 解析JS脚本



## 还有什么可以发送请求

- fetch
- websocket ( 请求地址： ws://xx.xx.xx:3000 )   双向通信协议
  - 聊天实时通讯
  - 金融股票大数据
- 小程序 [自带的]
  - wx.request()
  - uni.request()





