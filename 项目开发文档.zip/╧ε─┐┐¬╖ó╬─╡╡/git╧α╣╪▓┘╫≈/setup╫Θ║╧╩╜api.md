## vue  setup基本用法

- 参数说明

```vue
<script setup lang="ts">
	export default {
        #props 父传子数据-响应式对象
		setup(props, {attrs, slots, emit}){
            #attrs 属性-非响应式对象
            #slots 插槽 非响应式对象
            #emit 触发事件
        }
	}
</script>
```

- 注意

```js
setup 中`不能使用this`,this不指向组件实力，setup函数调用在 data，computed，property，methods 之前。
```

## setup 推荐用法

```js
#安装 
#快捷键v3p

```



注意：vue单文件内部会自动暴露API

```vue
<script setup ></script> 组合式API编译语法题。
```

- 优势。
  - 代码简洁，省略组件声明，暴露 数据，方法
  - 更好的 IDE 类型推论，减少语言服务器从代码中抽离类型的工作

## 组件使用


  ```js
<script setup >
  import HelloWorld from "./components/HelloWorld.vue";
</script>
  
<template>
    <HelloWorld msg="Hello Vue 3 + Vite" />
    <h1></h1>  #vue3 可以不用一个根组件包括
</template>
  ```

## 父子传参

### 父传子

- 父组件 Father.vue

```js
<base-child msg="你好啊"></base-child>
```

- 子组件 Child.vue

```js

```





## 9、在setup中的生命周期钩子

因为 `setup` 是围绕 `beforeCreate` 和 `created` 生命周期钩子运行的，所以不需要显式地定义它们。换句话说，在这些钩子中编写的任何代码都应该直接在 `setup` 函数中编写。

下表包含如何在 [setup ()](https://v3.cn.vuejs.org/guide/composition-api-setup.html) 内部调用生命周期钩子：

| 选项式 API        | Hook inside `setup`               |
| ----------------- | :-------------------------------- |
| `beforeCreate`    | Not needed*    不需要             |
| `created`         | Not needed*    不需要             |
| `beforeMount`     | `onBeforeMount` 挂载之前          |
| `mounted`         | `onMounted`    页面加载完成时执行 |
| `beforeUpdate`    | `onBeforeUpdate`                  |
| `updated`         | `onUpdated`                       |
| `beforeUnmount`   | `onBeforeUnmount`                 |
| `unmounted`       | `onUnmounted`  页面销毁时执行     |
| `errorCaptured`   | `onErrorCaptured`                 |
| `renderTracked`   | `onRenderTracked`                 |
| `renderTriggered` | `onRenderTriggered`               |
| `activated`       | `onActivated`                     |
| `deactivated`     | `onDeactivated`                   |

```typescript
<script setup lang="ts">
import { onMounted, onActivated, onUnmounted, onUpdated, onDeactivated } from 'vue';
// 读取环境变量
const mode = import.meta.env;
//   import HeadMenu from '@/components/head-menu/index.vue';
 onMounted(() => {
 console.log("组件挂载")
 })

 onUnmounted(() => {
 console.log("组件卸载")
 })

 onUpdated(() => {
 console.log("组件更新")
 })
 onActivated(() => {
 console.log("keepAlive 组件 激活")
 })

 onDeactivated(() => {
 console.log("keepAlive 组件 非激活")
 })
</script>
```

