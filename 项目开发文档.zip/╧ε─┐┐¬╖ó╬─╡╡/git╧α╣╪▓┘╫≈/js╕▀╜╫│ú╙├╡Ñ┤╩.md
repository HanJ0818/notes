`prototype`      	显式原型  : 通过构造函数的prototype属性可以找到原型

`__proto__`      	隐式原型 : 通过实例对象的`__proto__`属性可以找到原型

`constructor`  	构造器 : class中的内置函数,用于创建对象时会自动执行,

改变函数中的this指向

`apply` : 调用函数,第一个参数为需要给函数矫正的this,后面参数都会放在数组中   对象.方法.apply(矫正对象,[实参1,实参2...]

`call`  :调用函数,第一个参数为需要矫正的this,后面的为调用函数时需要传递的实参列表,  语法:  对象.方法.call(矫正对象,实参1,实参2..)

`bind`  :不会调用函数,只会固定一个函数体重的this指向为第一个参数,返回一个函数体 const   函数名=对象.方法.bind(矫正对象);

`instanceof`		检测引用数据类型值的类型 ,检测前面的对象是否由后面的构造函数所创建  常用用来检测对象是否由一个构造函数创建的

`typeof`   			 检测基本数据类型 

`Object.prototype.toString.call()`       返回的值为  [object 类型]

`Array.isArray() `:判断一个对象是否是数组

`create`				创建    语法 const obj= Object.create(对象);   创建一个空属性对象的原型为传入的对象  即  : `obj.__proto`__==对象

`static `				静态    在类中使用static修饰的方法为静态方法,只能被类调用

`extends`			  继承    子类继承父类,语法   语法:` 子类  extends 父类{}`

`super`				  超级    在子类的构造函数中(第一句)调用父类构造函数用来保证子类对象创建之前先创建父类对象

`export `				导出    属性导出   `export let 变量=值`、对象导出export { 变量}、默认导出 `export default {}`

`import`				导入    属性和对象: import {} from "路径"; 默认导出对应的导入:  import 对象 from "路径"  

`default`			  默认  

`params`				参数    `axios.get("url",{params:{  }   })`

`Promise`			  用于表示一个异步操作的最终完成 (或失败)及其结果值   new Promise()

​							  三种状态  :初始 、成功、 失败

​							  两种状态改变：1.  初始==》成功    2.  初始==》失败

​							  语法：        new Promise((resolve,reject)=>{    

​														//resolve(); //将状态由初始改为成功

​														//reject();   //将状态由初始改为失败

​												  }).then(()=>{}).catch(()=>{})

`resolve`			  将初始状态改变为成功

`reject`				将初始状态改变为失败

`then`    				捕获成功状态 

`catch`				  捕获失败状态 

`async `				  异步    

​								    普通函数  :   async  function 函数名(){}

​									匿名函数:   let fn=async  function(){}

​									回调函数    :  window.setTimeout( async ()=>{},1000);

​									箭头函数   :  let   函数名= async ()=>{}

​									立即执行  :( async funciton(){}())

`await`				  等待  : 用于配合async来管理异步,将异步代码变为同步  , 注意:   用await修饰的函数调用 ,函数必须返回Promise .

`interceptors`   拦截    

​								请求拦截  :  axios.interceptors.request.use((config)=>{   return config;  }   ,(error)=>{ return Promise.reject(error)  })

​								响应拦截:axios.interceptors.response.use((response)=>{   return response;  }   ,(error)=>{ return Promise.reject(error)  })

​								

`request`			  请求

`response`			响应

`assets`				存放今静态资源文件

`components`		组件

`methods`			  方法

`computed`			计算

`once`					一次

`cloak`				  遮盖

`watch`				  观察

`beforeCreate`   创建前

`created`			  创建后

`beforeMount`      挂载前

`mounted`              挂载后

`beforeUpdate`   更新前

`updated`              更新后

`beforeDestroy` 销毁前

`destroyed`           

销毁后

`作用域 ` : 标识符能够被标识符访问到的`范围`

`作用域分类` :  全局、局部（函数作用域）、块

`作用域链` : 当标识符在使用标识符的过程中会先在自身的作用域下查找,如果找不到就到上一级的作用域中找,以此类推一直找到window下,找到就用找不到就报错.

`闭包` ： 函数+跨作用域访问标识符     （在函数的内部跨作用域访问函数外部的变量）

`iife` : 立即执行函数     (funciton(){})()         (function(){}())       [function(){}()]

 `闭包的两种实现`：  在函数的内部使用return 将函数内部的函数体返回给外部调用  ， 将函数体挂在到window上，在函数的外面使用window访问

`原型` ： 

​		构造函数的prototype属性可以找到原型对象

​		对象的`__proto__`属性可以找到原型对象  

​        原型对象上都有一个constructor属性,指向构造函数本身

`原型链` :  一个对象是由构造函数所创建的,构造函数的prototype属性可以找到原型对象,原型对象又是由其他的构造函数所创建的,一次类推最终会找到Object构造函数,Object的构造函数的原型对象的原型是null

`原型链`:  在一个对象去使用某个方法时会先在自身找方法,如果自身没有则沿着原型链查找,一直找到 Object的原型上,如果找到就使用,找不到就报错



`解构`  :   

​	`解构数组` ：  变量的顺序要和数组元素的顺序一致    let [a,b]=[1,2]:  将1的值赋值给a   将2的值赋值给b

​    `解构对象`  :    变量的名称必须要和对象的属性名一致    let {a,b}={a:1,b:2}  :将a属性的值赋值给变量a  将b属性的值赋值给变量b  

`对象的简洁表示` : 当变量的名称与对象的属性名称一致是可以省略对象的赋值过程.  例如  let a=1;   赋值给对象时 const obj={a};

`展开`

​    `展开字符串` :   将字符串转为数组 [...字符串名]

​	`展开数组` :  浅拷贝  [...数组名]      合并数组 :[...数组1,...数组2]

​	`展开对象` :  浅拷贝  {...对象名}      合并对象 : {...对象1,...对象2}

`回调`  :  现在不执行回头再执行    

`继承`  :

​	`原型链继承`  :让子类的原型等于父类对象     子类.prototype=new 父类();

​	`寄生式组合继承`     

   			1. 继承属性     在子类中使用calll方法调用父类方法     父类.call(this,参数列表);
   			2. 继承方法     子类.prototype=Object.create(父类.prototype)
   			3. 重置构造函数    子类.prototype.constructor=子类本身

`class`

class 类名 extends 父类{

//构造函数

constructor(参数列表){

super(参数);

this.属性 =参数;

}



//原型方法

方法名(){}

//静态方法,只能通过类名访问

static 方法名(){}

//属性的另一种表现

属性=值;

}



