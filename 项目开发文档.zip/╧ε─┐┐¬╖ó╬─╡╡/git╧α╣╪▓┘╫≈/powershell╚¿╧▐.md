##### 以管理员身份运行PowerShell

- win10搜索powershell 右键以管理员方式运行

##### 执行：get-ExecutionPolicy，回复Restricted，表示状态是禁止的

##### 执行：set-ExecutionPolicy RemoteSigned

##### 选择Y

  注意：一定要以管理员的身份运行PowerShell，不是cmd窗口！

