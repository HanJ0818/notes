# JS终极总结

## JS的组成 [熟练掌握]

### 1 ES规范 [重点 !!!]      

​	作用:  学习这个规范,才知道js的语法,知道如何写代码不会报错,写js代码,要遵循这个规范.

#### 1.1 关键字

- var	
- let
- const
- function
- `class`    [ES6 ---->  JS高级的第四天会讲  类]

#### 1.2 运算符

```js
+ - * / % ++ -- += -= *= /=
```

#### 1.3 条件控制语句

- 条件判断

  ```js
  if (条件) {
      /* 代码 */
  } else if (条件2) {
      /* 代码 */
  } else {
      /* 代码 */
  }
  ```

#### 1.4 分支判断

```js
switch (形参) {
    case 条件1:
        /* 代码 */
        break;
     case 条件2:
        /* 代码 */
        break;
    default: 
        /* 代码 */
}
```

#### 1.5 三目运算符

```js
# 如果条件是true  就走表达式1  否则 就走表达式2     作用: 取代if else  让代码短一点哦,哥
条件 ? 表达式1 : 表达式2         

```

4. 循环

- for
- for in
- for of
- while
- forEach
- map
- filter
- some
- every

#### 1.6 内置对象

##### Array [重点!!!!!]

- 属性

   length

  

- 数组方法[重点!!!]


​      

| 方法      | 说明                                                     |
| --------- | -------------------------------------------------------- |
| unshift   | 首位添加                                                 |
| shift     | 删除首位                                                 |
| push      | 尾部添加                                                 |
| pop       | 删除尾部最后一个元素                                     |
| map       | 循环, 把每一次循环的返回值,全部放入一个新数组,返回新数组 |
| forEach   | 数组循环                                                 |
| some      | 循环,某一个元素满足条件,就返回true,否则返回false         |
| every     | 循环,每一个都满足,就返回true,否则返回false               |
| find      | 找到满足条件的第一个元素,返回该元素                      |
| findIndex | 找到满足条件的第一个元素, 返回该元素的索引               |
| filter    | 过滤,把满足条件的元素放入一个新数组,返回这个新数组       |
| concat    | 连接数组                                                 |
| flat      | 数组降维                                                 |
| includes  | 判断是否包含                                             |
| indexOf   | 判断元素出现的索引,没有就返回-1                          |
| join      | 数组分割为字符串                                         |
| reverse   | 反转数组                                                 |
| sort      | 排序                                                     |
| splice    | 删除/添加/替换  元素                                     |
| slice     | 截取数组                                                 |
|           |                                                          |
|           |                                                          |
|           |                                                          |
|           |                                                          |
|           |                                                          |
|           |                                                          |
|           |                                                          |
|           |                                                          |
|           |                                                          |



##### String [重点!!!!!]

- 属性
  
  length
  
- 方法 [重点 !!!!!]
  
   | 方法        | 说明                                            |
   | ----------- | ----------------------------------------------- |
   | concat      | 连接字符串                                      |
   | includes    | 判断是否包含                                    |
   | indexOf     | 返回字符串在字符串中出现的索引,没有就返回-1     |
   | charAt      | 返回指定索引的字符                              |
   | replace     | 替换                                            |
   | slice       | 截取字符串,包含开头,不包含结尾                  |
   | split       | 字符串分割成数组                                |
   | substr      | 截取字符串, 开始的索引,  和截取几个             |
   | substring   | 截取字符串, 开始索引和结束索引, 含开头,不含结尾 |
   | toLowerCase | 转小写                                          |
   | toUpperCase | 转大写                                          |
   | trim        | 去除首尾空白                                    |
| charCodeAt  | 返回指定索引的字符的编码                        |
   

##### Date

- 方法  [会查询即可]
  
     | 方法        | 说明       |
     | ----------- | ---------- |
     | getFullYear | 获取年     |
     | getMonth    | 获取月     |
     | getDate     | 获取日     |
     | getHours    | 获取小时   |
     | getMinutes  | 获取分钟   |
     | getSeconds  | 获取秒     |
     | getDay      | 获取星期   |
     | getTime     | 获取时间戳 |
     |             |            |

#####    Math

   - 方法  [会查询即可]

     | 方法名 | 说明     |
     | ------ | -------- |
     | ceil   | 向上取整 |
     | floor  | 向下取整 |
     | max    | 最大值   |
     | min    | 最小值   |
     | random | 随机数   |
     | round  | 四舍五入 |
     |        |          |

#####    Number 

   - 方法 [会查询即可]

     | 方法名     | 说明        |
     | ---------- | ----------- |
     | toFixed(n) | 保留n位小数 |
     |            |             |

#####    Object

   - 方法   [会查询即可]

     | 方法   | 说明                    |
     | ------ | ----------------------- |
     | keys   | 获取所有键名 结果是数组 |
     | assign | 合并多个对象            |
     |        |                         |

### 2 DOM [理解, 会查询使用]

- 作用:  操作节点,对节点`为所欲为`

- DOM操作:

  - 查询dom(找到节点, 才能操作它哦, 哥)

    ```js
    #H4
    document.getElementById()
    document.getElementsByClassName()
    
    #H5 [吐血推荐!!!]
    document.querySelector()
    document.querySelectorAll()
    ```

  - 删除节点:

       ```js
    # 删除节点自己
    dom节点.remove()
    
    # 删除子节点
    dom节点.removeChild()
    ```

  - 修改节点:

       ```js
    dom节点.innerHTML = '新的内容'
    dom节点.innerText = '新的内容'
    dom节点.textContent = '新的内容'  // 推荐
    ```

  - 增加节点:

       ```js
    let elem = document.createElement('标签名') // 创建一个节点 
    
    dom容器.appendChild( elem ) // 把刚才创建好的节点 添加进入指定的dom容器中.
    ```

  - 操作节点上的属性:

    ```js
    dom节点.style.属性 = '新的样式'
    dom节点.className = '新的类名'
    dom节点.id = '新的id'
    
    input节点.value = '新的值'
    
    dom节点.dataset.自定义属性名 = 'xxx'  // H5 data-* 自定义属性
    ```

### 3 BOM [掌握 location 和 history, 其他会查询即可]

- 作用:   操作浏览器,对浏览器 `为所欲为`
- BOM内置的对象:
  - location  [掌握 !!!]  操作地址栏
    - origin
    - href         [******************]
    - host
    - hostname
    - pathname
    - search   [******************]
    - hash
    - port
    - protocol
  - history [掌握 !!!]  操作历史记录
    - back()
    - forward()
    - go()
  - screen     获取屏幕信息
    - width
    - height
  - navigator
    - userAgent
    - language
  - window
    - alert
    - setTimeout
    - setInterval
    - open

