## 1、配置本地用户名及邮箱

```js
# 配置用户名
git config --global user.name "用户名"
# 配置邮箱
git config --global user.email "邮箱地址"
```


  以上命令执行结束后，可用 git config --global --list命令查看配置是否成功

## 2、git生成公钥

 1）在git bash窗口输入下面指令即可生成带注释的公钥

```js
ssh-keygen -t rsa -C '邮箱地址'
```


 2）设置存放公钥的位置，默认的话直接回车键确认

 3）输入密码和确认密码，不设置密码直接按回车键

## 3、git查看ssh公钥的方法

 1）通过git bash命令窗口

```js
①直接输入cat ~/.ssh/id_rsa.pub即可查看
```

  ②逐步进入目录打开文件

   a.进入.ssh目录：cd ~/.ssh

   b.找到id_rsa.pub文件：ls

   c.查看公钥：cat id_rsa.pub 或者vim id_rsa.pub

 2）直接打开用户目录下的.ssh文件夹，打开里面的id_rsa.pub文件即可查看
