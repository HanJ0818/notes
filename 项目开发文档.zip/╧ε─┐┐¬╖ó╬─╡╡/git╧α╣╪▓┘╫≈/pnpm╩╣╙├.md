# pnpm 使用

## pnpm 概念

pnpm 相比较于 yarn/npm 这两个常用的包管理工具在性能上也有了极大的提升，根据目前官方提供的 [benchmark](https://link.zhihu.com/?target=https%3A//pnpm.io/benchmarks) 数据可以看出在一些综合场景下比 npm 4倍 yarn2倍不止！！！

## 1安装

```js
#npm i pnpm -g
```

## 2 设置淘宝镜像

```js
#查看源
pnpm config get registry 
#切换淘宝源
pnpm config set registry http://registry.npm.taobao.org 
```

## 3  使用

```js
pnpm install 包   
pnpm i 包   
#如果安装不全依赖  要么 pnpm i 缺少的依赖 要么下面方式
#pnpm i --shamefully-flatten
pnpm add 包    // -S  默认写入dependencies
pnpm add -D    // -D devDependencies
pnpm add -g    // 全局安装
```

## 4 删除包

```js
pnpm remove 包                            //移除包
pnpm remove 包 --global                   //移除全局包
```

## 5 设置存储路径【了解】

```js
pnpm config set store-dir /path/to/.pnpm-store
```

## 6 注意事项

- powersell 如果不能启动pnpm 可以开启powershell权限

```js
#以管理员身份运行power shell
set-executionpolicy remotesigned
#选 Y
```

- 或者去appData里面删除 pnpm.ps1 文件

```js
 #地址
 C:\Users\你的用户\AppData\Roaming\npm
```

- 有的依赖安装不上 需要切换安装命令

```js
 # pnpm i --shamefully-flatten
```

