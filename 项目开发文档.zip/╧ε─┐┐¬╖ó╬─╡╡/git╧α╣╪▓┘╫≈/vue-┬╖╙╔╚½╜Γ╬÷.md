# vue-路由

## 路由前置守卫

```js
//作用:权限管理
router.beforeEach((to, from, next) => {
  #to 到哪儿去
  #from 从哪来
  #next 放行
})
```

## 路由解析守卫

`router.beforeResolve` 注册一个全局守卫。这和 `router.beforeEach` 类似，区别是在导航被确认之前，**同时在所有组件内守卫和异步路由组件被解析之后**，解析守卫就被调用。

## 路由后置守卫

```js
//路由后置守卫
router.afterEach(() => {
  //关闭进度条
  NProgress.done()
})
```

## 路由独享守卫

```js
{
    path: "/modifier",
    component: () => import('@/views/modifier'),
    beforeEnter: (to, from, next) => {//路由独享守卫
      /* 
        单独控制当前路由 让有权限的人进来
      */
      if (true) {
        next()
      } else {
        next('/')
      }
    }
  },
```

## 组件守卫

```js
//组件守卫--进入前
  beforeRouteEnter(to, from, next) {
    // 在渲染该组件的对应路由被 confirm 前调用
    // 不！能！获取组件实例 `this`
    // 因为当守卫执行前，组件实例还没被创建
    next()
  },
  //组件守卫--更新前
  beforeRouteUpdate(to, from, next) {
  // 在当前路由改变，但是该组件被复用时调用
  // 举例来说，对于一个带有动态参数的路径 /foo/:id，在 /foo/1 和 /foo/2 之间跳转的时候，
  // 由于会渲染同样的 Foo 组件，因此组件实例会被复用。而这个钩子就会在这个情况下被调用。
  // 可以访问组件实例 `this`
    next()
  },
  //组件守卫--离开前
  beforeRouteLeave(to, from, next) {
    // 导航离开该组件的对应路由时调用
    // 可以访问组件实例 `this`
    next()
  }
```

## 完整导航解析流程

1. 导航被触发。
2. 在失活的组件里调用 `beforeRouteLeave` 守卫。
3. 调用全局的 `beforeEach` 守卫。
4. 在重用的组件里调用 `beforeRouteUpdate` 守卫 (2.2+)。
5. 在路由配置里调用 `beforeEnter`。
6. 解析异步路由组件。
7. 在被激活的组件里调用 `beforeRouteEnter`。
8. 调用全局的 `beforeResolve` 守卫 (2.5+)。
9. 导航被确认。
10. 调用全局的 `afterEach` 钩子。
11. 触发 DOM 更新。
12. 调用 `beforeRouteEnter` 守卫中传给 `next` 的回调函数，创建好的组件实例会作为回调函数的参数传入。

```js
进入路由组件
# beforeEach 全局前置守卫
# beforeEnter 路由独享守卫
# beforeRouteEnter 组件前置守卫
# afterEach 全局后置守卫

退出路由组件
# beforeRouteLeave 组件离开守卫
进新页面
# beforeEach 全局前置守卫
# beforeEnter 路由独享守卫
# beforeRouteEnter 组件前置守卫
# afterEach 全局后置守卫
```

## 综合示例  不F5刷新页面

- router/index.js 配置路由

```js
{
     path: '/redirect/:path(.*)', //匹配所有路径 redirect/其他任意路径
     //path: '/redirect/*',*还是:path(.*) 看vue-router版本 
     component: () => import('@/views/redirect')
},
```

- views 下面建立页面级别组件 redirect.jsx

```js
export default {
  beforeMount() { //挂载之前就跳转回去了 
    const { params, query } = this.$route
    const { pathMatch } = params
    //跳转回去 并携带路由参数
    this.$router.replace({ path: '/' + pathMatch, query })
  },
  render() {//render函数 里面可以写jsx模板语法[js里面写html]
    return <div></div>
  }
}
```

- 刷新操作

```js
refresh() {
    //解构全路径
    const { fullPath } = this.$route
    //跳转到 redirect 地址 携带全路径 
    //replace 不在浏览器历史栈里面 留下当前地址
    this.$router.replace({
        path: '/redirect' + fullPath
    })
},
```

- 会执行路由所有的 钩子函数[生命周期]

## 后端路由权限

- 发请求 后端返回数组`路由表`

  ```js
  #携带token发请求获取计算好的路由表
  authorityMessage(store.getters.token).then(res => {
      // console.log('解析后端动态路由', res)
      const asyncRouter = addRouter(res.data) // 进行递归解析 res.data就是路由表
  })
  ```

- 写一个方法 根据路由表 计算出`符合格式`的路由结构

  ```js
  /**
   * 生成路由
   * @param {Array} routerlist 格式化路由
   * @returns
   */
  export function addRouter(routerlist) {
    const router = []
    try {
      routerlist.forEach((e, index) => {
        let e_new = {
          path: e.path,
          name: e.name,
          component: resolve => {
            e.component === 'layout' ? require([`@/layout`], resolve) : require([`@/views${e.component}`], resolve)
          }
        }
        if (e.redirect) {
          e_new = { ...e_new, redirect: e.redirect }
        }
        console.log(e_new, 'e')
        if (e.generateMenu === 0) {
          e_new = { ...e_new, hidden: true }
        }
        if (e.icon !== '' && e.title !== '') {
          if (e.breadcrumb === 0) {
            e_new = { ...e_new, meta: { title: e.title, icon: e.icon, breadcrumb: false, permit: e.permit }}
          } else {
            e_new = { ...e_new, meta: { title: e.title, icon: e.icon, breadcrumb: true, permit: e.permit }}
          }
        } else if (e.title !== '' && e.icon === '') {
          if (e.breadcrumb === 0) {
            e_new = { ...e_new, meta: { title: e.title, breadcrumb: false, permit: e.permit }}
          } else {
            e_new = { ...e_new, meta: { title: e.title, breadcrumb: true, permit: e.permit }}
          }
        }
        if (e.children) {
          const children = addRouter(e.children)
          // 保存权限
          e_new = { ...e_new, children: children }
        }
        router.push(e_new)
      })
    } catch (error) {
      console.error(error)
      return []
    }
    return router
  }
  ```

  

- 合并路由

  ```js
   //router4 addRoutes destroyed
  #动态添加路由  router4版本没得addRoutes  router3版本可以addRoutes
  accessRoutes.forEach((route) => {
      router.addRoute(route)
  })
  
  #hack方法  确保所有路由都添加进来
  next({ ...to, replace: true })
  ```

- 测试实例 

```js
import Vue from "vue";
import VueRouter from "vue-router";


//后端动态路由
/* generatemenu: 是否显示在侧边栏 */
/* perimit：是否需要写入权限数组 */
/* breadcrumb：是否显示在面包屑 */
/* 0：不是 1：是 */
const asycnRoutes =
  [
    {
      path: '/',
      name: '',
      component: 'Layout',
      redirect: '/dashboard',
      title: '',
      icon: '',
      id: 1,
      parentId: null,
      generatemenu: 1,
      permit: 1,
      breadcrumb: 1,
      children: [{
        path: 'dashboard',
        name: 'Dashboard',
        component: '/sales-trend/index',
        redirect: '',
        title: '首页',
        icon: 'home',
        id: 11,
        parentId: 1,
        generatemenu: 0,
        breadcrumb: 0,
        permit: 1
      }]
    },
    {
      path: '/qiantao', //路由地址
      name: 'Qiantao', //路由名称
      component: 'Layout', //路由框架组件
      redirect: '/qiantao/index',//路由重定向地址
      title: '嵌套的路由',//路由title字段 左侧菜单使用
      icon: 'qiantao',//图标 左侧菜单使用
      id: 3, //唯一标识符
      parentId: null, //parentId null代表没有父级 是一级路由
      generatemenu: 1, //代表有侧边菜单 1代表左侧有显示
      permit: 0, // 权限数组 0不写入
      breadcrumb: 1,  //面包屑导航 1代表展示
      children: [
        {
          path: 'list',
          name: 'List',
          component: '/qiantao/components/index',
          redirect: '',
          title: '嵌套首页',
          icon: '',
          id: 31,
          parentId: 3, //parentId 有id代表 自己是次级, 自己有父级路由
          generatemenu: 1,
          breadcrumb: 1,
          permit: 0
        },
        {
          path: 'record',
          name: 'Record',
          component: '/qiantao/components/record',
          redirect: '',
          title: '嵌套列表',
          icon: '',
          id: 32,
          parentId: 3,
          generatemenu: 1,
          breadcrumb: 1,
          permit: 0
        },
        {
          path: 'details',
          name: 'Details',
          component: '/qiantao/components/details',
          redirect: '',
          title: '详情',
          icon: '',
          id: 33,
          parentId: 3,
          generatemenu: 0,
          breadcrumb: 1,
          permit: 0
        }
      ]
    }
  ]

//计算路由方法
const addRouter = (routeList) => {
  //创建一个空数组
  let routes = []
  //循环路由数组
  routeList.forEach(route => {
    //如果有儿子 且儿子不为空
    if (route.children?.length > 0) {
      //创建数组装其他的属性
      let temp = {
        path: route.path,
        name: route.name,
        component: `() => import(@/views${route.component})`,
        redirect: route.redirect,
        meta: {
          title: route.title,
          icon: route.icon,
          id: route.id,
          parentId: route.parentId,
          generatemenu: route.generatemenu,
          breadcrumb: route.breadcrumb,
          permit: route.permit
        }
      }
      //儿子 单独迭代出来
      let children = addRouter(route.children)
      //把儿子和其他属性 组合
      temp.children = children
      //再push进 数组
      routes.push(temp)
    } else {
      //没有儿子 直接push进数组
      routes.push({
        path: route.path,
        name: route.name,
        component: `() => import(@/views${route.component})`,
        redirect: route.redirect,
        meta: {
          title: route.title,
          icon: route.icon,
          id: route.id,
          parentId: route.parentId,
          generatemenu: route.generatemenu,
          breadcrumb: route.breadcrumb,
          permit: route.permit
        }
      })
    }
  })

  //最后得到一个拼好字段的数组
  return routes
}


const router = new VueRouter({
  routes,
});

//路由全局前置守卫 作用:权限管理
router.beforeEach((to, from, next) => {
  console.log('beforeEach');
  NProgress.start()
  /* 
    from 从哪来
    to 到哪儿去
    next 放行
  */

  let token = 'test token'
  if (token) {
    //在路由跳转之前 开始计算动态路由 并添加进去
    let accessRoutes = addRouter(asycnRoutes)
    // router.addRoutes(accessRoutes)
    //确保 路由正确的添加进去
    next({ ...to, replace: true })
  } else {
    next('/login')
  }
})

//路由后置守卫
router.afterEach(() => {
  console.log('afterEach');
  //关闭进度条
  NProgress.done()
})

export default router;
```

## 动态组件 

```js
<component :is="组件名"></component>
```

## keep-alive 缓存组件

- 如果被缓存组件包裹 会产生缓存 不会被销毁
- 来回切换 执行生命周期 activated 和deactivated
  - 初始化还是会执行 created mounted等待
  - 切换组件 并不会被销毁

```js
<keep-alive>
    <!-- 组件壳子 -->
    <component :is="'Child'+current+'Vue'"></component>
</keep-alive>
```

### keep-alive示例 

- router/index.js 配置需要缓存的组件的meta

```js
{
    path: "/c-zhiling",
    component: () => import('@/views/c-zhiling'),
    meta: {
      cache: true //表示需要缓存
    }
},
```

- App.vue 写上v-if的判断

```js
<keep-alive>
    #如果当前路由meta里面需要缓存 就给它套一层keep-alive的壳子
     <router-view v-if="$route.meta.cache"></router-view>
</keep-alive>
#如果没就不需要套壳字
<router-view v-if="!$route.meta.cache"></router-view>
```

## transition 动画

- name 动画名称 需要自己写css

```js
#例如name="fade-transform"
/* fade-transform AppMain*/
.fade-transform-leave-active,
.fade-transform-enter-active {
  transition: all 0.3s;
}

.fade-transform-enter-from {
  opacity: 0;
  transform: translateX(-30px);
}

.fade-transform-leave-to {
  opacity: 0;
  transform: translateX(30px);
}
.fade-transform-active {
  position: absolute;
}
```

- mode  离开&进入模式
  - out-in 先出再进
  - in-out 先进再出



