# nvm node版本管理工具

概念:nvm 可以管理node js版本, 让用户在一个电脑里面拥有几个 nodejs 用于切换nodejs版本

## 下载

https://github.com/coreybutler/nvm-windows/releases 

[nvm-setup.exe ](https://github.com/coreybutler/nvm-windows/releases/download/1.1.9/nvm-setup.exe)     下载它[安装有yes选yes]

## 使用

- 打开cmd  **注意 一定要用管理员身份打开不然切换报错**

## 命令

```js
#查看当前node 列表
nvm list

#下载 node版本
nvm install node版本号
例如 nvm install 10.2.0

#切换
nvm use node版本号

#删除 
nvm uninstall node版本号
```



