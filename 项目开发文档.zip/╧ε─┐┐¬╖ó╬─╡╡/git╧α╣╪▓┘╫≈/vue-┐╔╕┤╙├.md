# vue-可复用

## Diff 算法

- 同级对比 找到对应的点进行`最小粒度`替换
- v-for 循环给key 的原因, 提高 diff 算法的精确性 提高性能,避免bug

## 自定义指令

```js
一个指令定义对象可以提供如下几个钩子函数 (均为可选)：

# bind：只调用一次，指令第一次绑定到元素时调用。在这里可以进行一次性的初始化设置。
    #指令钩子函数会被传入以下参数：

    #el：指令所绑定的元素，可以用来直接操作 DOM。
    #binding：一个对象，包含以下 property：

inserted：被绑定元素插入父节点时调用 (仅保证父节点存在，但不一定已被插入文档中)。

update：所在组件的 VNode 更新时调用，但是可能发生在其子 VNode 更新之前。指令的值可能发生了改变，也可能没有。但是你可以通过比较更新前后的值来忽略不必要的模板更新 (详细的钩子函数参数见下)。

我们会在稍后讨论渲染函数时介绍更多 VNodes 的细节。

componentUpdated：指令所在组件的 VNode 及其子 VNode 全部更新后调用。

unbind：只调用一次，指令与元素解绑时调用。


#示例
bind 钩子函数，第一次绑定时调用，可以在这里做初始化设置
#el: 作用的 dom 对象
#value: 传给指令的值，也就是我们要 copy 的值
    
bind(el, { value }) {
    el.$value = value; // 用一个全局属性来存传进来的值，因为这个值在别的钩子函数里还会用到
    el.handler = () => {
        if (!el.$value) {
            // 值为空的时候，给出提示，我这里的提示是用的 ant-design-vue 的提示，你们随意
            console.log('无法复制');
            return;
        }
        // 动态创建 textarea 标签
        const textarea = document.createElement('textarea');
        // 将该 textarea 设为 readonly 防止 iOS 下自动唤起键盘，同时将 textarea 移出可视区域
        textarea.readOnly = 'readonly';
        textarea.style.position = 'absolute';
        textarea.style.left = '-9999px';
        // 将要 copy 的值赋给 textarea 标签的 value 属性
        textarea.value = el.$value;
        // 将 textarea 插入到 body 中
        document.body.appendChild(textarea);
        // 选中值并复制
        textarea.select();
        // textarea.setSelectionRange(0, textarea.value.length);
        const result = document.execCommand('Copy');
        if (result) {
            console.log('复制成功');
        }
        document.body.removeChild(textarea);
    };
    // 绑定点击事件，就是所谓的一键 copy 啦
    el.addEventListener('click', el.handler);
},
    // 当传进来的值更新的时候触发
    componentUpdated(el, { value }) {
        el.$value = value;
    },
        // 指令与元素解绑的时候，移除事件绑定
        unbind(el) {
            el.removeEventListener('click', el.handler);
        },
            
#使用
<button v-copy='value值'>复制</button>


#注册
import directives from './directive'
//循环注册所有指令
Object.keys(directives).forEach(key => {
  Vue.directive(key, directives[key])
})
```

## 全局过滤器

![image-20220421112807331](images/image-20220421112807331.png)

```js
#注册
//引入过滤器js 另取名filters
import * as filters from './filters'
//注册全局过滤器
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})
```

## mixin 混入 推荐局部混入

- 作用:抽离JS逻辑  方便复用

![image-20220421113002259](images/image-20220421113002259.png)

```js
#用法
#1 引入mixin配置
import calcTableWidth from '../../mixin/tableWidthResize'
export default {
  data() {
    return {
      msg: '自己的数据'
    }
  },
  #2 注入mixin配置
  mixins: [calcTableWidth],
  methods: {
    calcTableWidth() {
      console.log(666);
    }
  }
}
```

## listeners  $  ​attrs

- 作用: element-ui等二次封装使用
- 可以去像漏斗一样 接住父组件传过来的 属性(attrs) 和方法(listeners)
  - 如果子组件 有props接住了属性, $attrs 只能接住剩下的属性


![image-20220421151127729](images/image-20220421151127729.png)

- index.js

```js
#1 引入公共组件
import MyBtn from './my-btn'
import MyPagination from './my-pagination'

#2 把公共组件装在一个数组中
const components = [
    MyBtn,
    MyPagination
]

#3 创建一个 install 方法 里面进行循环注册全局组件
const install = (Vue) => {
    components.forEach(componet => {
        //Vue.component 注册全局组件 参数1 组件名称 参数2组件本身
        Vue.component(componet.name, componet)
    })
}

#4 输出组件和install方法
export default {
    ...components,//导出组件
    install//导出install方法
}
```

- main.js

```js
#注册自定义的二次封装组件
import erci from './components'
# 像插件一样 去使用自己的二次封装组件
Vue.use(erci)
```

## 插件使用

```js
#必须暴露一个 install方法
MyPlugin.install = function (Vue, options) {
  // 1. 添加全局方法或 property
  Vue.myGlobalMethod = function () {
    // 逻辑...
  }

  // 2. 添加全局资源
  Vue.directive('my-directive', {
    bind (el, binding, vnode, oldVnode) {
      // 逻辑...
    }
    ...
  })

  // 3. 注入组件选项
  Vue.mixin({
    created: function () {
      // 逻辑...
    }
    ...
  })

  // 4. 添加实例方法
  Vue.prototype.$myMethod = function (methodOptions) {
    // 逻辑...
  }
    
  //5. 全局注册组件
  Vue.component('组件名',组件)
}

#使用
Vue.use(插件)
```

