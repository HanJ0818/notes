# JS面试专题

## 基本语法

- 运算符

  ```
  + - * / % ++ -- += -= *= /=
  ```

- 关键字

  ```
  var let const class function super extends ....
  ```

- 循环

  ```js
  for
  for in 
  for of
  map
  filter
  forEach
  every
  some
  findIndex
  ```

  

- 条件判断、分支判断、三目运算

  ```js
  if else 
  switch
  true ? a : b
  ```

  

## 内置对象

### Array

- `Array.prototype`

### String

- `String.prototype`

## 数据类型

- 基本类型： 7种
- 引用类型： 三种
- 类型检测 ：
  - typeof
  - instanceof
  - Object.prototype.toString.call() 

## 高级特性

- 栈内存

  - 栈内存： 一个出口，先入后出。

    - 题目：

      ```js
      class Stack {
          constructor() {
              
          }
          in() {
              
          }
          out() {
              
          }
          top() {
              
          }
          size() {
              
          }
      }
      
      const stack = new Stack()
      
      stack.in('x')
      stack.in('y')
      stack.in('z')
      
      stack.top()   // z
      stack.size()  // 3
      stack.out('z') // z 
      
      stack.top() // y
      stack.size() // 2
      ```

      

- 闭包

  - 使用场景
    - 防抖
      -  在事件被触发n秒后再执行回调，如果在这n秒内又被触发，则重新计时。 
    - 节流
      -  规定在一个单位时间内，只能触发一次函数。如果这个单位时间内触发多次函数，只有一次生效。 

- 作用域

- 原型和原型链

- this

  - call
  - apply

- ES6

  - 解构、扩展运算符、模板字符串、类、模块导入导出

- Promise

  ```js
  function request(url, cb) {
      setTimtout(() => {
          cb(数据)
      }， 2000)
  }
  
  request('http://example.com', function (res) {
      console.log(res)
  })
  
  
  function requestAsync() {
      return new Promise(resolve => {
          resolve(数据)
      })
  }
  
  requestAsync().then(res => {
      console.log(res)
  })
  ```

  

- async  /   await

  ```js
  getData().then(res => {
      
  }).catch(err => {
      
  })
  
  try {
     let res = await getData()
  } catch (err) {
      // 处理错误
  }
  ```

  

- 继承   (ES5 / ES6)

  - ES5:  `寄生组合式继承`

    ```js
    父类.call(this, 形参1， 形参2) // 调用父类构造函数 继承属性
    
    // 让 子类.prototype.__proto__ === 父类.prototype 继承方法
    子类.prototype = Object.create(父类.prototype) 
    
    子类.prototype.constructor = 子类
    ```

  - ES6

    ```js
    class 子类 extends 父类 { // 继承属性
        constructor() {
            super() // 继承方法
        }
    }
    ```

- 递归

  - 自己调用自己
  
  - 有出口
  
  - 面试题：
  
    ```js
    const obj = [{
       id:1,
       name: 'admin',
    },{
       id:2,
       name: 'xiao',
       children: [
           {id: 21, name: 'guest'}
       ]
    },
                {
       id:3,
       name: 'fei',
    }]
    ```
  
    

## 综合逻辑

- 考察的是内置对象api的使用
- 考察运算符
- 考察循环和判断
- 考察递归
- 对象和数组的灵活使用
- 考察对知识的综合运用能力
- 简单的算法

```js
let arr = ['A华东', 'B华西', 'C华南', 'A华北', 'B华东', 'A华南', 'A华北']

/*
  需求是排序：
  A B C  华东 华南 华西 华北
*/


/*
   1. 归类
    [A的放一个数组]
    [B的放一个数组]
    [C的放一个数组]
   2. 对3个数组按照 东南西北排序
   3. 合并三个数组
*/
```





