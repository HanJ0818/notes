# movie-app开发笔记

# DAY01

## 1 搭建项目环境

- 安装脚手架

  ```js
  yarn global add create-react-app
  ```

  

- 创建项目

  ```js
  create-react-app movie-app
  ```

  

- 清理项目目录

  - 搭建标准工程目录

  - 清空不要的东西

  - 引入重置样式

    ```js
    // reset.css
    import './assets/css/reset.css'
    ```

- 安装sass

  ```js
  yarn add sass -D  // 只要安装这个模块即可 编译sass的webpack配置 脚手架内置了的
  ```

  

## 2 配置路由

- 安装路由

```js
yarn add react-router-dom@5.2.0
```



### 2.1 创建所有一级组件

### 2.2 配置路由

```js
import React from 'react'
import { HashRouter, Route, Switch } from 'react-router-dom'

// 引入组件
import ChooseSeat from './views/chooseSeat'
import CitySelect from './views/citySelect'
import Login from './views/login'
import Reg from './views/reg'
import Mine from './views/mine'
import MovieDetail from './views/movieDetail'
import Home from './views/home'
import Error404 from './views/error/Error404'

export default function App() {
  return (
    <div style={{ height: '100%', backgroundColor: 'green' }}>
      {/* 一级路由 */}
      <HashRouter>
        <Switch>
          <Route path="/" exact component={Login} />
          <Route path="/reg" component={Reg} />
          <Route path="/mine" component={Mine} />
          <Route path="/movie-detail" component={MovieDetail} />
          <Route path="/choose-seat" component={ChooseSeat} />
          <Route path="/city-select" component={CitySelect} />
          <Route path="/home" component={Home} />
          <Route component={Error404} />
        </Switch>
      </HashRouter>
    </div>
  )
}
```

### 2.3 如何在项目中写scss 和 less

react项目`create-react-app`搭建的，自带了 scss

- 安装sass 和 node-sass   【如果要集成sass，只需要安装模块】

  ```js
  yarn add sass node-sass -D         // sass-loader  sass
  ```

- 如何知道安装了没有呢？

  ```js
  # 解包  可以把 create-react-app 脚手架底层的webpack配置 暴露出来 我们可以看 和 修改
  yarn eject  
  ```

- 修改 `webpack.config.js` 配置  【如果需要支持less 需要修改webpack的配置】

  ```js
  # 在 config/webpack.config.js 
  {
    test: lessRegex,
    use: getStyleLoaders(
      {
        importLoaders: 3,
        sourceMap: isEnvProduction
          ? shouldUseSourceMap
          : isEnvDevelopment,
      },
      'less-loader'
    ),
    sideEffects: true,
  },
  ```

- 安装两个模块 `less-loader` 和 `less`

  ```js
   yarn add less@4.1.1 less-loader@7.0.0 -D    // less-loader less
  
   "less": "4.1.1",
   "less-loader": "7.0.0",
  ```



## 3 ant design 【ui框架 ui组件库】

### 3.1 介绍

- ant design pc端 （pc端组件库）
- ant design mobile 移动端 （移动端组件库）
- ant design pro 专业版pro（基于pc端组件库 写的一套模板）



ui组件库：

- Vue
  - pc端
    - element-ui
    - view-ui
    - ant design vue
  - 移动端
    - vant
- React
  - pc端
    - ant design
  - 移动端
    - ant design mobile
- 基于ui库写好的管理系统模板 ( 在模板的基础上 进行二次开发 修改即可 )
  - ant design pro
  - element admin
  - iview admin
- uni-app 混合式开发框架， 自带组件库，它的标签就是组件



### 3.2 按需引入 

性能优化，减少打包体积。

- 安装  `ant design mobile`

  ```js
  yarn add antd-mobile 
  ```

- 安装webpack的插件

  ```js
  yarn add babel-plugin-import -D
  ```

- 再安装一个插件

  ```js
  yarn add react-app-rewired@2.0.2-next.0
  ```

- 修改 package.json

  ```js
  "scripts": {
      "start": "react-app-rewired start",
      "build": "react-app-rewired build",
      "test": "react-app-rewired test"
    },
  ```

- 根目录创建配置文件

  - `config-overrides.js`

    ```js
    const { injectBabelPlugin } = require('react-app-rewired');
    module.exports = function override(config, env) {
        config = injectBabelPlugin(
            ['import', { libraryName: 'antd-mobile', libraryDirectory: 'es', style: 'css' }],
            config,
        );
        return config;
    };
    ```

- 引入组件 使用组件

  ```js
  import { Button, InputItem } from 'antd-mobile';
  ```






# DAY02

## 1 登录组件

```js
import React, { useState } from 'react'
import './login.scss'

import { WhiteSpace, Flex, InputItem, WingBlank, Button } from 'antd-mobile';
import { Link } from 'react-router-dom';

// 引入ajax
import { checkLogin } from '../../api/user'

// 引入图片 两种方式
// import logo from '../../assets/imgs/logo.jpg' // es6的模块化导入 logo直接就是图片地址
// const logo1 = require('../../assets/imgs/logo.jpg')
// console.log(logo1.default) // require是node的模块化 引入的logo1是一个对象 需要.default才能拿到图片地址


// 引入图片
import icon_user from '../../assets/imgs/icon_user.png'
import icon_pwd from '../../assets/imgs/icon_pwd.png'

export default function Index() {
    // 使用hooks定义状态
    let [userName, setUserName] = useState('')
    let [userPwd, setUserPwd] = useState('')
    let [show, setShow] = useState('none')

    // 改变用户名
    const changeUserName = (val) => {
        setShow('none')
        setUserName(val)
    }

    // 改变密码
    const changeUserPwd = (val) => {
        setShow('none')
        setUserPwd(val)
    }

    /* 登录提交 */
    const submitForm = async () => {
        // 发送登录请求
        let res = await checkLogin({ acc: userName, pwd: userPwd })

        let { code } = res.data;

        if (code === 1) {
            // 跳转到首页
            window.location.href = '/#/home'
        } else if (code === 0) {
            setShow('block')
        }
    }

    return (
        <div className="login">
            <WhiteSpace />

            {/* logo */}
            <Flex justify="center">
                <div className="logo">
                    <img width="200" height="160" src={require('../../assets/imgs/logo.jpg').default} alt="logo" />
                </div>
            </Flex>

            <WhiteSpace />

            <WingBlank >
                {/* 账号 */}
                <InputItem
                    placeholder="请输入账号"
                    clear
                    value={userName}
                    onChange={changeUserName}
                >
                    <div style={{ backgroundImage: `url(${icon_user})`, backgroundSize: 'cover', height: '22px', width: '22px' }} />
                </InputItem>

                {/* 密码 */}
                <InputItem
                    type="password"
                    placeholder="请输入密码"
                    clear
                    value={userPwd}
                    onChange={changeUserPwd}
                >
                    <div style={{ backgroundImage: `url(${icon_pwd})`, backgroundSize: 'cover', height: '22px', width: '22px' }} />
                </InputItem>
            </WingBlank>

            <WhiteSpace />

            <WingBlank>
                <Button onClick={submitForm} style={{ backgroundColor: '#FF2F66', color: '#fff' }}>登录</Button>
            </WingBlank>

            <WhiteSpace />

            <WingBlank>
                <WhiteSpace />
                <p style={{ display: show }} className="err-msg">登录失败,请检查账号或密码 !</p>
                <WhiteSpace />
            </WingBlank>

            <WingBlank>
                <Flex justify="between">
                    <Link to="/reg">前往注册</Link>
                    <Link to="/reg">忘记密码</Link>
                </Flex>
            </WingBlank>

            <p className="tip">
                <span>
                    登录/注册表示用户同意网站用户协议
                </span>
            </p>
        </div>
    )
}

```



## 2 热映组件

### 2.1 Home.js

```js
import React, { useState } from 'react'
import { TabBar } from 'antd-mobile'
import './home.scss'

// 引入组件
import Main from '../main/Main'
import Celima from '../celima/Celima'
import Mine from '../mine'

// 引入静态资源
import icon_main from '../../assets/imgs/icon_main.png'
import icon_main_s from '../../assets/imgs/icon_main_s.png'
import icon_celima from '../../assets/imgs/icon_celima.png'
import icon_celima_s from '../../assets/imgs/icon_celima_s.png'
import icon_my from '../../assets/imgs/icon_my.png'
import icon_my_s from '../../assets/imgs/icon_my_s.png'

export default function Home() {
    // 定义状态
    let [curActive, setActive] = useState('main')

    return (
        <div className="home">
            {/* tabbar底部导航 */}
            <TabBar
                unselectedTintColor="#949494"
                tintColor="#FF2F66"
                barTintColor="white"
            >
                <TabBar.Item
                    title="热映"
                    key="热映"
                    icon={<div style={{
                        width: '22px',
                        height: '22px',
                        background: `url(${icon_main}) center center /  21px 21px no-repeat`
                    }}
                    />
                    }
                    selectedIcon={<div style={{
                        width: '22px',
                        height: '22px',
                        background: `url(${icon_main_s}) center center /  21px 21px no-repeat`
                    }}
                    />
                    }
                    selected={curActive === 'main'}
                    onPress={() => {
                        setActive('main')
                    }}
                >
                    <Main />
                </TabBar.Item>

                <TabBar.Item
                    title="影院"
                    key="影院"
                    icon={<div style={{
                        width: '22px',
                        height: '22px',
                        background: `url(${icon_celima}) center center /  21px 21px no-repeat`
                    }}
                    />
                    }
                    selectedIcon={<div style={{
                        width: '22px',
                        height: '22px',
                        background: `url(${icon_celima_s}) center center /  21px 21px no-repeat`
                    }}
                    />
                    }
                    selected={curActive === 'celima'}
                    onPress={() => {
                        setActive('celima')
                    }}
                >
                    <Celima />
                </TabBar.Item>

                <TabBar.Item
                    title="我的"
                    key="我的"
                    icon={<div style={{
                        width: '22px',
                        height: '22px',
                        background: `url(${icon_my}) center center /  21px 21px no-repeat`
                    }}
                    />
                    }
                    selectedIcon={<div style={{
                        width: '22px',
                        height: '22px',
                        background: `url(${icon_my_s}) center center /  21px 21px no-repeat`
                    }}
                    />
                    }
                    selected={curActive === 'my'}
                    onPress={() => {
                        setActive('my')
                    }}
                >
                    <Mine />
                </TabBar.Item>
            </TabBar>
        </div>
    )
}

```

### 2.2 热映组件 main.js

```js
import React, { useEffect, useState } from 'react'
import { Tabs, WingBlank } from 'antd-mobile'

// 引入ajax方法
import { getMovieList } from '../../api/movie'

import './main.scss'

import Card from './card/Card'

export default function Main() {
    // 定义状态
    let [movieList1, setMovieList1] = useState([])
    let [movieList2, setMovieList2] = useState([])

    // tab选项卡切换
    const tabs = [
        { title: "正在热映" },
        { title: "即将上映" },
    ];

    // hooks函数
    useEffect(async () => {
        // 发送ajax请求 获取电影列表数据
        let res1 = await getMovieList({
            state: 1
        })

        let res2 = await getMovieList({
            state: 2
        })

        console.log(res1.data.data)
        console.log(res2.data.data)

        // 把获取到的电影列表 放入state状态中
        setMovieList1(res1.data.data)
        setMovieList2(res2.data.data)
    }, [])

    return (
        <Tabs tabs={tabs}
            tabBarPosition="top"
            initialPage={0}
            tabBarActiveTextColor="#FF2F66"
            tabBarUnderlineStyle={{ border: '1px solid #FF2F66' }}
            style={{ position: 'sticky' }}
        >
            {/* 内容1 */}
            <div>
                <WingBlank>
                    {
                        movieList1.map(v => {
                            return <Card key={v.id} data={v} />
                        })
                    }
                </WingBlank>
            </div>

            {/* 内容2 */}
            <div>
                <WingBlank>
                    {
                        movieList2.map(v => {
                            return <Card key={v.id} data={v} />
                        })
                    }
                </WingBlank>
            </div>
        </Tabs>
    )
}
```

### 2.3 组件封装

- Card.js

  ```js
  import React from 'react'
  import './card.scss'
  
  export default function Card(props) {
      // 解构
      let { image, name, point, director, actors } = props.data;
      return (
          <div className="card">
              <img className="img" src={image} alt="图片" />
              <div className="info">
                  <h3>{name}</h3>
                  <p>淘票票评分: {point}</p>
                  <p>导演: {director}</p>
                  <p>主演: {actors}</p>
              </div>
              <span className="btn">购票</span>
          </div>
      )
  }
  
  ```

  

## 3 接口三层封装

- request.js   --- 工具函数层

  ```js
  /*
      ajax请求工具函数
  */
  
  import axios from "axios";
  axios.defaults.baseURL = 'http://129.211.169.131:3333';
  axios.defaults.timeout = 10000;
  
  // 请求拦截
  axios.interceptors.request.use(config => {
      return config;
  }, err => {
      return Promise.reject(err)
  })
  
  // 响应拦截
  axios.interceptors.response.use(response => {
      return response
  }, err => {
      return Promise.reject(err)
  })
  
  // 暴露出去
  export default axios;
  
  ```

- api   --- ajax接口管理层

  ```js
  /* 用户相关的ajax函数 */
  import request from '../utils/request'
  
  /* 登录请求 */
  export const checkLogin = (data) => {
      return request({
          url: '/login',
          method: 'post',
          data
      })
  }
  ```

  

- 组件调用层 -- react的组件就是js文件

  ```js
  // 引入ajax
  import { checkLogin } from '../../api/user'
  
  /* 登录提交 */
  const submitForm = async () => {
      // 发送登录请求  ...................
      let res = await checkLogin({ acc: userName, pwd: userPwd })
  
      let { code } = res.data;
  
      if (code === 1) {
          // 跳转到首页
          window.location.href = '/#/home'
      } else if (code === 0) {
          setShow('block')
      }
  }
  ```




# DAY03

## 1 高德地图定位（react中）

- 在 `index.html` 中，引入高德地图，城市定位的api

  ```js
      <!-- 引入高度地图城市定位js -->
      <script
        type="text/javascript"
        src="//webapi.amap.com/maps?v=2.0&key=bf8722f286c544429f5c2d918c01b669&plugin=AMap.CitySearch"
      ></script>
  
  
  # 注意： 这个key需要开发者自己申请，在企业中开发，如果使用高德地图， key是公司申请（公司花钱买功能，个人开发者可能没有）。
  ```

- 把AMap挂载在window下。

  ```js
  <script>
        window.AMap = AMap;
  </script>
  ```

- 在组件中，完成定位功能

  ```js
    // hooks 当成生命周期使用
      useEffect(() => {
          /* 获取当前城市 */
          function getCurCity() {
              let citysearch = new window.AMap.CitySearch();
              citysearch.getLocalCity((status, result) => {
                  if (status === 'complete' && result.info === 'OK') {
                      if (result && result.city && result.bounds) {
                          let cityinfo = result.city;
                          setTimeout(() => {
                              setCity(cityinfo) // 修改状态
                          }, 2000)
                      }
                  } else {
                      setCity('定位失败') // 修改状态
                  }
              });
          }
          getCurCity();
      }, [])
  ```

  













