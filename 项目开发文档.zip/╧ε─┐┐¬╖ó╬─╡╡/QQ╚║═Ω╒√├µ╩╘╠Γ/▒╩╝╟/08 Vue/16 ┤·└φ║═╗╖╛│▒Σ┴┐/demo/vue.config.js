module.exports = {
	publicPath:'./'
}

