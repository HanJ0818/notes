export default{
	state:{
		pathList:'这是地址管理',
		num:1
	},
	getters:{},
	mutations:{
		add( state ){
 			state.num++;
		}
	},
	actions:{}
}