export default{
	state:{
		cartList:['a','b','c']
	},
	getters:{},
	mutations:{},
	actions:{}
}