<template>
	<div>	
		<Header></Header>
		<Footer></Footer>
	</div>
</template>

<script type="text/javascript">
import Header from './Header'
import Footer from './Footer'
export default {

	components:{
		Header,
		Footer
	}

}	
</script>