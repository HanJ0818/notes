<template>
  <div class="about">
    <h1>其他</h1>
  </div>
</template>
